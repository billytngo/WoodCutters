var s_HelloWorld = "res/HelloWorld.png";
var s_CloseNormal = "res/CloseNormal.png";
var s_CloseSelected = "res/CloseSelected.png";

var g_resources = [
    //image
    s_HelloWorld,
    s_CloseNormal,
    s_CloseSelected

    //plist

    //fnt

    //tmx

    //bgm

    //effect
];